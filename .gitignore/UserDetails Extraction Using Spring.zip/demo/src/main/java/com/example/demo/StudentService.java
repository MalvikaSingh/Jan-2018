package com.example.demo;

import java.util.HashMap;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/rest/student")
class UserService{
 
   @RequestMapping(value="/",method = RequestMethod.GET)
   public HashMap<Long,UserDetails> getAllUsers(){
      return Application.hmUser;
   }
}